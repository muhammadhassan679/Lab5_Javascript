function loadStudent(id, callback) {
    setTimeout(() => {
        if (id !== 101) return callback(new Error("Student does not exist"));

        callback(null, {
            id: 101,
            name: "Ali",
            completedPrerequisite: true,
            registeredCourses: []
        });
    }, 300);
}

function checkPrerequisites(student, callback) {
    setTimeout(() => {
        if (!student.completedPrerequisite) {
            return callback(new Error("Prerequisite not completed"));
        }
        callback(null, student);
    }, 300);
}

function checkSeats(course, callback) {
    setTimeout(() => {
        if (course.seats <= 0) return callback(new Error("Course is full"));
        callback(null, course);
    }, 300);
}

function registerCourse(student, course, callback) {
    setTimeout(() => {
        if (student.registeredCourses.includes(course.code)) {
            return callback(new Error("Already registered"));
        }

        student.registeredCourses.push(course.code);
        callback(null, {
            studentId: student.id,
            course: course.code,
            status: "REGISTERED"
        });
    }, 300);
}

function registerStudent(studentId, course) {
    loadStudent(studentId, (error, student) => {
        if (error) return console.log(error.message);

        checkPrerequisites(student, (error, student) => {
            if (error) return console.log(error.message);

            checkSeats(course, (error, course) => {
                if (error) return console.log(error.message);

                registerCourse(student, course, (error, result) => {
                    if (error) return console.log(error.message);
                    console.log("Registration Successful:", result);
                });
            });
        });
    });
}

const course = { code: "CS401", seats: 10 };
registerStudent(101, course);
