const results = [
    { id: 1, name: "Ali", department: "CS", course: "FSWD", marks: 82 },
    { id: 2, name: "Sara", department: "CS", course: "FSWD", marks: 91 },
    { id: 3, name: "Usman", department: "SE", course: "FSWD", marks: 47 },
    { id: 4, name: "Hina", department: "AI", course: "FSWD", marks: 73 },
    { id: 5, name: "Ahmed", department: "SE", course: "FSWD", marks: 64 },
    { id: 6, name: "Zoya", department: "AI", course: "FSWD", marks: 91 }
];

function getGrade(marks) {
    if (typeof marks !== "number" || !Number.isFinite(marks) || marks < 0 || marks > 100) {
        return { grade: "Invalid", status: "Invalid", gradePoints: 0 };
    }

    let grade, gradePoints;
    if (marks >= 85) { grade = "A"; gradePoints = 4.0; }
    else if (marks >= 80) { grade = "A-"; gradePoints = 3.7; }
    else if (marks >= 75) { grade = "B+"; gradePoints = 3.3; }
    else if (marks >= 70) { grade = "B"; gradePoints = 3.0; }
    else if (marks >= 65) { grade = "B-"; gradePoints = 2.7; }
    else if (marks >= 60) { grade = "C+"; gradePoints = 2.3; }
    else if (marks >= 50) { grade = "C"; gradePoints = 2.0; }
    else { grade = "F"; gradePoints = 0; }

    return { grade, status: marks >= 50 ? "Pass" : "Fail", gradePoints };
}

// A. Result Processing
const processedResults = results.map(student => ({
    ...student,
    ...getGrade(student.marks)
}));
console.log("A. Processed Results:", processedResults);

// B. Ranked Merit List. Copy before sort because sort changes its array.
const rankedList = [...processedResults].sort((a, b) => {
    if (b.marks !== a.marks) return b.marks - a.marks;
    return a.name.localeCompare(b.name);
});
console.log("B. Ranked List:", rankedList);

// C. Department Statistics
const departments = {};
processedResults.forEach(student => {
    const dept = student.department;
    if (!departments[dept]) {
        departments[dept] = { students: 0, totalMarks: 0, highest: student.marks, passed: 0 };
    }
    departments[dept].students++;
    departments[dept].totalMarks += student.marks;
    if (student.marks > departments[dept].highest) departments[dept].highest = student.marks;
    if (student.marks >= 50) departments[dept].passed++;
});

Object.keys(departments).forEach(dept => {
    departments[dept].average = Number(
        (departments[dept].totalMarks / departments[dept].students).toFixed(2)
    );
    delete departments[dept].totalMarks;
});
console.log("C. Department Statistics:", departments);

// D. Academic Queries
const firstAbove85 = results.find(s => s.marks > 85);
const firstFailedIndex = results.findIndex(s => s.marks < 50);
const anyFailed = results.some(s => s.marks < 50);
const allValid = results.every(s => s.marks >= 0 && s.marks <= 100);
const overallAverage = results.reduce((sum, s) => sum + s.marks, 0) / results.length;
const aboveAverage = results.filter(s => s.marks > overallAverage);
const topThree = rankedList.slice(0, 3);

console.log("First student above 85:", firstAbove85);
console.log("First failed student index:", firstFailedIndex);
console.log("Any student failed:", anyFailed);
console.log("All marks valid:", allValid);
console.log("Overall average:", overallAverage.toFixed(2));
console.log("Above average students:", aboveAverage);
console.log("Top three students:", topThree);
console.log("Original results unchanged:", results);
