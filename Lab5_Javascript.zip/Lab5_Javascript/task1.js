const applicants = [
    { id: "A101", name: "Sara Khan", age: "19", matricMarks: "91", intermediateMarks: "87", entryTest: "78", program: "BSCS", feePaid: "true" },
    { id: "A102", name: "Ahmed Ali", age: "twenty", matricMarks: "88", intermediateMarks: "", entryTest: "72", program: "BSSE", feePaid: "false" },
    { id: "A103", name: "Hassan", age: "18", matricMarks: "76", intermediateMarks: "83", entryTest: "91", program: "BSAI", feePaid: "true" }
];

const programs = ["BSCS", "BSSE", "BSAI"];

function processApplicant(applicant) {
    const age = Number(applicant.age);
    const matric = Number(applicant.matricMarks);
    const intermediate = Number(applicant.intermediateMarks);
    const entryTest = Number(applicant.entryTest);

    const missing =
        applicant.age.trim() === "" ||
        applicant.matricMarks.trim() === "" ||
        applicant.intermediateMarks.trim() === "" ||
        applicant.entryTest.trim() === "" ||
        applicant.name.trim() === "" ||
        applicant.program.trim() === "";

    const invalidNumber =
        !Number.isFinite(age) ||
        !Number.isFinite(matric) ||
        !Number.isFinite(intermediate) ||
        !Number.isFinite(entryTest);

    const validMarks =
        matric >= 0 && matric <= 100 &&
        intermediate >= 0 && intermediate <= 100 &&
        entryTest >= 0 && entryTest <= 100;

    const validAge = age >= 17 && age <= 30;
    const validProgram = programs.includes(applicant.program);

    if (missing || invalidNumber || !validMarks || !validAge || !validProgram) {
        return { id: applicant.id, name: applicant.name, merit: null, status: "INVALID DATA" };
    }

    const merit = matric * 0.20 + intermediate * 0.30 + entryTest * 0.50;
    let status;

    if (merit >= 70 && entryTest >= 60 && intermediate >= 60 && applicant.feePaid === "true") {
        status = "SELECTED";
    } else if (merit >= 60) {
        status = "WAITING";
    } else {
        status = "REJECTED";
    }

    return {
        id: applicant.id,
        name: applicant.name,
        age,
        program: applicant.program,
        merit: Number(merit.toFixed(2)),
        status
    };
}

const processed = applicants.map(processApplicant);
console.log("Admission Results:", processed);

const validApplicants = processed.filter(a => a.merit !== null);
const invalidApplicants = processed.filter(a => a.merit === null);

const highestMerit = validApplicants.length
    ? validApplicants.reduce((a, b) => a.merit > b.merit ? a : b)
    : null;

const lowestMerit = validApplicants.length
    ? validApplicants.reduce((a, b) => a.merit < b.merit ? a : b)
    : null;

const averageMerit = validApplicants.length
    ? validApplicants.reduce((sum, a) => sum + a.merit, 0) / validApplicants.length
    : 0;

const programCount = {};
for (const program of programs) {
    programCount[program] = applicants.filter(a => a.program === program).length;
}

console.log("Valid Applicants:", validApplicants.length);
console.log("Invalid Applicants:", invalidApplicants.length);
console.log("Highest Merit:", highestMerit);
console.log("Lowest Merit:", lowestMerit);
console.log("Average Merit:", averageMerit.toFixed(2));
console.log("Program Counts:", programCount);
