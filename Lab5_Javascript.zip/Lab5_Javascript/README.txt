Lab 5 - Hands-on Practice on Advanced JavaScript
================================================

Contents
--------
task1.js       Admission decision and data sanitization
task2.js       Academic performance and array methods
task3.js       Safe student profile update and object references
task4.js       Classes, inheritance, this, call, and bind
task6.js       Callback-based registration (no Promises)
task7.js       Promise-based registration and service results
task8.js       Concurrent dashboard, fake API tests, and timeout
Lab5Task5/    ES-module transcript project:
  package.json
  main.js
  Student.js
  gradeUtils.js
  transcriptService.js

Requirements
------------
Install Node.js (no extra npm packages are needed).

How to run
----------
Open a terminal in this folder and run:
  node task1.js
  node task2.js
  node task3.js
  node task4.js
  node task6.js
  node task7.js
  node task8.js

For Task 5, run:
  cd Lab5Task5
  node main.js

Notes
-----
- Task 2 and Task 5 use an assumed 4.0 GPA-point mapping because the assignment
  specifies grade bands but does not provide a grade-point table.
- Task 7 deliberately makes the SMS demonstration fail so allSettled can show
  both fulfilled and rejected results.
- Task 8's fake API tests work offline. The fetchWithTimeout example uses a real
  network request and is commented out in the main flow.
