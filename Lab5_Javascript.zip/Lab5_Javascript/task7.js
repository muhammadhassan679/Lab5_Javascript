function getStudent(id) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (id !== 101) return reject(new Error("Student not found"));
            resolve({
                id: 101,
                name: "Ali",
                completedPrerequisite: true,
                registeredCourses: []
            });
        }, 200);
    });
}

function getCourse(code) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (code !== "CS401") return reject(new Error("Course not found"));
            resolve({ code: "CS401", seats: 10 });
        }, 200);
    });
}

function checkPrerequisites(student, course) {
    return new Promise((resolve, reject) => {
        if (!student.completedPrerequisite) {
            return reject(new Error("Prerequisite not completed"));
        }
        resolve({ student, course });
    });
}

function checkSeats(data) {
    return new Promise((resolve, reject) => {
        if (data.course.seats <= 0) return reject(new Error("Course is full"));
        resolve(data);
    });
}

function registerStudent(data) {
    return new Promise((resolve, reject) => {
        if (data.student.registeredCourses.includes(data.course.code)) {
            return reject(new Error("Already registered"));
        }

        data.student.registeredCourses.push(data.course.code);
        resolve({
            studentId: data.student.id,
            course: data.course.code,
            status: "REGISTERED"
        });
    });
}

function sendEmail(result) {
    return new Promise(resolve => {
        setTimeout(() => resolve("Email sent for " + result.course), 300);
    });
}

function sendSMS(result) {
    return new Promise((resolve, reject) => {
        setTimeout(() => reject(new Error("SMS service failed")), 200);
    });
}

function writeAuditLog(result) {
    return new Promise(resolve => {
        setTimeout(() => resolve("Audit log saved"), 100);
    });
}

// Part A and B: Registration, followed by independent services
getStudent(101)
    .then(student => {
        return getCourse("CS401").then(course => ({ student, course }));
    })
    .then(data => checkPrerequisites(data.student, data.course))
    .then(data => checkSeats(data))
    .then(data => registerStudent(data))
    .then(result => {
        console.log("Registration:", result);
        return Promise.allSettled([
            sendEmail(result),
            sendSMS(result),
            writeAuditLog(result)
        ]);
    })
    .then(results => {
        const report = results.map((result, index) => ({
            service: ["Email", "SMS", "Audit"][index],
            status: result.status
        }));
        console.log("Post-registration report:", report);
    })
    .catch(error => console.log("Registration failed:", error.message))
    .finally(() => console.log("Registration process finished."));

// Part C: First successful server
function serverOne() {
    return new Promise((resolve, reject) => {
        setTimeout(() => reject(new Error("Server 1 failed")), 200);
    });
}

function serverTwo() {
    return new Promise(resolve => {
        setTimeout(() => resolve({ code: "CS401", title: "Advanced JavaScript" }), 400);
    });
}

Promise.any([serverOne(), serverTwo()])
    .then(course => console.log("Course found:", course))
    .catch(error => console.log("All servers failed:", error.errors))
    .finally(() => console.log("Server search finished."));
