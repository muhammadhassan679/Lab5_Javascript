async function getJSON(url, fetchImplementation) {
    const response = await fetchImplementation(url);

    if (!response.ok) {
        throw new Error("HTTP error: " + response.status);
    }

    return await response.json();
}

const users = [
    { id: 1, name: "Ali", department: "CS" },
    { id: 2, name: "Sara", department: "CS" },
    { id: 3, name: "Usman", department: "SE" },
    { id: 4, name: "Hina", department: "AI" }
];

const courses = [
    { id: 1, name: "FSWD" },
    { id: 2, name: "DSA" },
    { id: 3, name: "AI" }
];

const results = [
    { id: 1, name: "Ali", department: "CS", marks: 82 },
    { id: 2, name: "Sara", department: "CS", marks: 91 },
    { id: 3, name: "Usman", department: "SE", marks: 47 },
    { id: 4, name: "Hina", department: "AI", marks: 73 }
];

async function fakeFetch(url) {
    await new Promise(resolve => setTimeout(resolve, 200));

    if (url === "/users") return { ok: true, status: 200, json: async () => users };
    if (url === "/courses") return { ok: true, status: 200, json: async () => courses };
    if (url === "/results") return { ok: true, status: 200, json: async () => results };

    if (url === "/network") throw new TypeError("Network failure");

    if (url === "/invalid-json") {
        return {
            ok: true,
            status: 200,
            json: async () => { throw new SyntaxError("Invalid JSON"); }
        };
    }

    if (url === "/404" || url === "/500") {
        return { ok: false, status: url === "/404" ? 404 : 500, json: async () => ({}) };
    }

    if (url === "/slow") {
        await new Promise(resolve => setTimeout(resolve, 1000));
        return { ok: true, status: 200, json: async () => ({ message: "Slow success" }) };
    }

    return { ok: false, status: 404, json: async () => ({ message: "Not found" }) };
}

async function loadDashboard() {
    const [userData, courseData, resultData] = await Promise.all([
        getJSON("/users", fakeFetch),
        getJSON("/courses", fakeFetch),
        getJSON("/results", fakeFetch)
    ]);

    const average = resultData.length
        ? resultData.reduce((sum, s) => sum + s.marks, 0) / resultData.length
        : 0;

    const highestStudent = resultData.length
        ? resultData.reduce((a, b) => a.marks > b.marks ? a : b)
        : null;

    const departments = {};

    resultData.forEach(student => {
        const dept = student.department;
        if (!departments[dept]) {
            departments[dept] = { students: 0, totalMarks: 0, passed: 0 };
        }
        departments[dept].students++;
        departments[dept].totalMarks += student.marks;
        if (student.marks >= 50) departments[dept].passed++;
    });

    Object.keys(departments).forEach(dept => {
        departments[dept].average = Number(
            (departments[dept].totalMarks / departments[dept].students).toFixed(2)
        );
        delete departments[dept].totalMarks;
    });

    const report = {
        totalStudents: userData.length,
        totalCourses: courseData.length,
        averageMarks: Number(average.toFixed(2)),
        highestStudent,
        failedStudents: resultData.filter(s => s.marks < 50).length,
        departments
    };

    console.log("Dashboard Report:", report);
    return report;
}

async function testGetJSON(url) {
    try {
        const data = await getJSON(url, fakeFetch);
        console.log(url, "Success:", data);
    } catch (error) {
        console.log(url, "Error:", error.name, error.message);
    }
}

async function runFakeTests() {
    await Promise.all([
        testGetJSON("/users"),
        testGetJSON("/404"),
        testGetJSON("/500"),
        testGetJSON("/network"),
        testGetJSON("/invalid-json"),
        testGetJSON("/slow")
    ]);
}

async function fetchWithTimeout(url, milliseconds) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), milliseconds);

    try {
        const response = await fetch(url, { signal: controller.signal });

        if (!response.ok) {
            throw new Error("HTTP error: " + response.status);
        }

        return await response.json();
    } catch (error) {
        if (error.name === "AbortError") {
            throw new Error("Request timed out");
        }
        throw error;
    } finally {
        clearTimeout(timer);
    }
}

async function main() {
    try {
        await loadDashboard();
        await runFakeTests();
    } catch (error) {
        console.log("Dashboard error:", error.name, error.message);
    }
}

main();

// For a real timeout test with internet access, uncomment:
// fetchWithTimeout("https://example.com", 5000)
//     .then(data => console.log("Real request:", data))
//     .catch(error => console.log("Request failed:", error.message));
