class Person {
    constructor(name, email) {
        this.name = name;
        this.email = email;
    }

    introduce() {
        return `My name is ${this.name} and my email is ${this.email}.`;
    }
}

class Student extends Person {
    constructor(name, email, rollNo, marks) {
        super(name, email);
        this.rollNo = rollNo;
        this.marks = marks;
    }

    introduce() {
        return super.introduce() + ` I am a student. My roll number is ${this.rollNo}.`;
    }

    getResult() {
        return this.marks >= 50 ? "Pass" : "Fail";
    }
}

class FacultyMember extends Person {
    constructor(name, email, employeeId, department) {
        super(name, email);
        this.employeeId = employeeId;
        this.department = department;
    }

    introduce() {
        return super.introduce() + ` I teach in the ${this.department} department.`;
    }
}

const student1 = new Student("Ali", "ali@uni.edu", 101, 82);
const student2 = new Student("Sara", "sara@uni.edu", 102, 45);
const teacher1 = new FacultyMember("Ahmed", "ahmed@uni.edu", 501, "Computer Science");
const teacher2 = new FacultyMember("Hina", "hina@uni.edu", 502, "Artificial Intelligence");

const users = [student1, student2, teacher1, teacher2];
users.forEach(user => console.log(user.introduce()));

console.log("Student result:", student1.getResult());
console.log("Is student:", student1 instanceof Student);
console.log("Is person:", student1 instanceof Person);
console.log("Is teacher a student:", teacher1 instanceof Student);

// call()
const guest = { name: "Dr. Ahmed", email: "ahmed@example.com" };
console.log(Person.prototype.introduce.call(guest));

// Detached method
const fn = student1.introduce;
try {
    console.log(fn());
} catch (error) {
    console.log("Detached method error:", error.message);
}

// bind()
const safeFunction = student1.introduce.bind(student1);
console.log(safeFunction());
