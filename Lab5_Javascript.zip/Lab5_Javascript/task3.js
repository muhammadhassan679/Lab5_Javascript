const student = {
    id: 101,
    name: "Ali",
    marks: 0,
    scholarship: false,
    address: { city: "Islamabad", sector: "F-10" },
    contact: { email: "ali@university.edu" }
};

const update = {
    name: "Ali Khan",
    address: { city: "Rawalpindi" },
    contact: { phone: "03001234567" }
};

// Object destructuring and renaming
const { name: oldName, marks = 0, ...otherDetails } = student;

// Nested destructuring and default values
const {
    address: { city, sector },
    contact: { email }
} = student;

// Array destructuring and array rest
const subjects = ["JavaScript", "DSA", "Networks"];
const [firstSubject, secondSubject, ...otherSubjects] = subjects;

// Rest parameters
function addMarks(...numbers) {
    return numbers.reduce((sum, n) => sum + n, 0);
}

// Object rest, spread, and property shorthand
function updateStudent(original, changes) {
    const { address: newAddress = {}, contact: newContact = {}, ...otherFields } = changes;

    return {
        ...original,
        ...otherFields,
        address: { ...original.address, ...newAddress },
        contact: { ...original.contact, ...newContact }
    };
}

const updatedStudent = updateStudent(student, update);

// Optional chaining and nullish coalescing
const phone = updatedStudent.contact?.phone ?? "No phone";
const cityName = updatedStudent.address?.city ?? "Unknown";

// Property shorthand
const studentInfo = { oldName, marks, city, sector, email };

console.log("Updated Student:", updatedStudent);
console.log("Phone:", phone);
console.log("City:", cityName);
console.log("Student Info:", studentInfo);
console.log("Other details:", otherDetails);
console.log("Subjects:", firstSubject, secondSubject, otherSubjects);
console.log("Total marks:", addMarks(10, 20, 30));

// Reference comparison
console.log("Student objects same:", student === updatedStudent);
console.log("Address objects same:", student.address === updatedStudent.address);
console.log("Contact objects same:", student.contact === updatedStudent.contact);
console.log("Original Student:", student);
