import Student from "./Student.js";
import { calculateAverage, calculateGPA } from "./gradeUtils.js";

export function processTranscript(rawData) {
    let data;

    try {
        data = JSON.parse(rawData);
    } catch {
        throw new SyntaxError("Invalid JSON data");
    }

    if (!Array.isArray(data)) {
        throw new TypeError("Transcript must be an array");
    }

    const ids = new Set();
    const report = [];

    for (const item of data) {
        if (!item || item.id === undefined || item.id === null || item.id === "") {
            throw new TypeError("Student ID is missing");
        }

        if (ids.has(item.id)) {
            throw new Error("Duplicate student ID: " + item.id);
        }
        ids.add(item.id);

        if (typeof item.name !== "string" || item.name.trim() === "") {
            throw new TypeError("Student name is missing");
        }

        if (!Array.isArray(item.courses) || item.courses.length === 0) {
            throw new TypeError("Student courses are missing");
        }

        const courses = item.courses.map(course => {
            if (!course || typeof course.code !== "string" || course.code.trim() === "") {
                throw new TypeError("Course code is missing");
            }

            if (typeof course.marks !== "number" || !Number.isFinite(course.marks)) {
                throw new TypeError("Course marks must be a number");
            }

            if (course.marks < 0 || course.marks > 100) {
                throw new RangeError("Course marks must be between 0 and 100");
            }

            return { ...course };
        });

        const student = new Student(item.id, item.name, courses);
        const marks = courses.map(course => course.marks);

        report.push({
            id: student.id,
            name: student.name,
            courses: student.courses,
            average: Number(calculateAverage(marks).toFixed(2)),
            GPA: Number(calculateGPA(marks).toFixed(2))
        });
    }

    return report;
}

export function reportToJSON(report) {
    return JSON.stringify(report, null, 2);
}
