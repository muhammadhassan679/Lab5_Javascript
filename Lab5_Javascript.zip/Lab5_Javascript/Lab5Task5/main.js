import Student from "./Student.js";
import {
    calculateGrade,
    calculateAverage,
    calculateGPA as getGPA
} from "./gradeUtils.js";
import { processTranscript, reportToJSON } from "./transcriptService.js";

const rawData = `
[
    {
        "id": 101,
        "name": "Ali",
        "courses": [
            { "code": "CS301", "marks": 81 },
            { "code": "CS302", "marks": 74 }
        ]
    }
]
`;

try {
    const report = processTranscript(rawData);
    console.log("Transcript Report:");
    console.log(reportToJSON(report));
    console.log("Grade of 81:", calculateGrade(81));
    console.log("Average:", calculateAverage([81, 74]).toFixed(2));
    console.log("GPA:", getGPA([81, 74]).toFixed(2));

    const example = new Student(102, "Sara", []);
    console.log("Student class:", example.name);

} catch (error) {
    console.log(error.name + ": " + error.message);
} finally {
    console.log("Transcript processing finished.");
}
