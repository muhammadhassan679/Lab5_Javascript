export function calculateGrade(marks) {
    if (typeof marks !== "number" || !Number.isFinite(marks) || marks < 0 || marks > 100) {
        throw new RangeError("Marks must be a number between 0 and 100");
    }

    if (marks >= 85) return "A";
    if (marks >= 80) return "A-";
    if (marks >= 75) return "B+";
    if (marks >= 70) return "B";
    if (marks >= 65) return "B-";
    if (marks >= 60) return "C+";
    if (marks >= 50) return "C";
    return "F";
}

export function calculateAverage(marks) {
    if (!Array.isArray(marks) || marks.length === 0) {
        throw new TypeError("Marks must be a non-empty array");
    }

    if (!marks.every(mark => typeof mark === "number" && Number.isFinite(mark) && mark >= 0 && mark <= 100)) {
        throw new RangeError("Every mark must be a number between 0 and 100");
    }

    return marks.reduce((sum, mark) => sum + mark, 0) / marks.length;
}

export function calculateGPA(marks) {
    const points = marks.map(mark => {
        const grade = calculateGrade(mark);
        if (grade === "A") return 4.0;
        if (grade === "A-") return 3.7;
        if (grade === "B+") return 3.3;
        if (grade === "B") return 3.0;
        if (grade === "B-") return 2.7;
        if (grade === "C+") return 2.3;
        if (grade === "C") return 2.0;
        return 0;
    });

    return points.reduce((sum, point) => sum + point, 0) / points.length;
}
